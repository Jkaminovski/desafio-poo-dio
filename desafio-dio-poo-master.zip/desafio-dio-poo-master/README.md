
## Treinando os conceitos do Paradigma da Orientação a Objetos em Java na prática.

Esse código faz parte do desafio de código proposto pela Digital Innovation One para consolidar por meio da prática os conceitos que norteiam o paradigma da orientação a objetos na linguagem Java. Aqui foram trabalhados a Abstração, Encapsulamento, Herança e Polimorfismo.
